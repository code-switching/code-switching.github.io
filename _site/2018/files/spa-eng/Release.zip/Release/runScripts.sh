#!/usr/bin/env bash

python3 collect_tweets.py -i $1 -o Files/tweets.tsv
python3 assembleDataFromOffsets.py -t Files/tweets.tsv -i $1 -o Files/data.tsv -m $2