Requirements
======================
Python 3.4
Tweepy (https://github.com/tweepy/tweepy)

Twitter app keys from https://apps.twitter.com/
Please put the keys (ONLY) in the empty twitter_auth.txt file in the following order (One per line, no white-spaces):
consumer_key
consumer_secret
access_token
access_token_secret


=======================
runScripts.sh
=======================

This script will run the python scripts listed below.
It will take the path to the offset file and the mode as input and will output the offsets with the tokens in the Files subdirectory. Existing files will be overwritten.
Modes:
gold - Will output tokens and gold standard labels.
reg - will output only tokens.

Example run:
sh runScripts.sh offsets.tsv gold

This is all that has to be run in order to obtain the data. Please be aware that we cannot control the availability of Twitter data and some tweets might be missing.


=======================
collect_tweets.py
=======================

Use this script to crawl Twitter for tweets using a user_id and tweet_id.

Input: (-i option)
Offset file containing the tweet_id and user_id in the first two columns.

Output: (-o option)
A tab separated file that has the tweet_id, user_id and tweet_text.


==========================
assembleDataFromOffsets.py
==========================

This script will get the tokens from the tweets using the provided offsets.
Requires a raw tweet file with columns tweet_id, user_id tweet_text (tab separated)
Requires an offset file with format tweet_id, user_id, start, end, [annotation] (tab separated)
There are two modes to run this script, reg and gold
gold mode will include Gold standard annotation as the last column, reg will not.

Options:
-t <TWEET_FILE>
-i <OFFSET_FILE>
-o <OUTPUT_FILE>
-m <MODE> (reg|gold)

Output:
A tab separated file with the following:
tweet_id, user_id, start, end, token, [annotation] # Annotation only with gold option.
